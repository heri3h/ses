<?php
require_once 'config/db.php';
require_once 'ads/ad-units.php';
$device = get_device_type();

// Jika kamu ingin fitur filter tetap jalan, tapi defaultnya ACAK:
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'random'; // Set default ke random

$orderMap = [
    'popular' => 'views DESC',
    'random'  => 'RAND()', // Ini yang bikin acak setiap dibuka
    'new'     => 'created_at DESC'
];
$orderBy = isset($orderMap[$sort]) ? $orderMap[$sort] : 'RAND()';

try {
    // Gunakan ORDER BY RAND() agar urutan game selalu berubah tiap refresh
    $stmt = $pdo->prepare("SELECT title, slug, image_url FROM games WHERE status = 'publish' ORDER BY $orderBy LIMIT :limit");
    $stmt->bindValue(':limit', 21, PDO::PARAM_INT);
    $stmt->execute();
    $games = $stmt->fetchAll();
} catch (PDOException $e) {
    $games = [];
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
    <title>ArcadeFun - Game Online Gratis</title>
    <link rel="stylesheet" href="assets/css/style.css?v=<?php echo time(); ?>">
    <?php include 'ads/ads-header.php'; ?>
</head>
<body>

<header>
    <a href="/" class="logo">ARCADE<span>FUN</span></a>
</header>

<div class="filter-bar">
    <a href="?sort=new" class="filter-btn <?php echo ($sort == 'new') ? 'active' : ''; ?>">✨ TERBARU</a>
    <a href="?sort=popular" class="filter-btn <?php echo ($sort == 'popular') ? 'active' : ''; ?>">🔥 POPULER</a>
    <a href="?sort=random" class="filter-btn <?php echo ($sort == 'random') ? 'active' : ''; ?>">🎲 ACAK</a>
</div>

<main class="main-container">
    <?php echo get_ad_unit('gm-header'); ?>
    <div id="game-grid" class="game-grid">
        <?php foreach ($games as $row): ?>
        <a href="game/<?php echo htmlspecialchars($row['slug']); ?>" class="game-card">
            <div class="card-inner">
                <img src="<?php echo htmlspecialchars($row['image_url']); ?>" alt="<?php echo htmlspecialchars($row['title']); ?>" loading="lazy">
                <div class="game-title"><?php echo htmlspecialchars($row['title']); ?></div>
            </div>
        </a>
        <?php endforeach; ?>
    </div>
    
    <div id="loader">🔄 Memuat Game Lainnya...</div>
</main>


<footer>
    <div class="footer-main">
        <div class="footer-brand">
            <a href="/" class="f-logo">ARCADE<span>FUN</span></a>
            <p>Destinasi utama para gamer untuk memainkan ribuan game HTML5 gratis tanpa download. Cepat, ringan, dan seru!</p>
        </div>

        <div class="footer-box">
            <h4>Navigasi</h4>
            <ul>
                <li><a href="/?sort=new">✨ Terbaru</a></li>
                <li><a href="/?sort=popular">🔥 Populer</a></li>
                <li><a href="/?sort=random">🎲 Acak</a></li>
            </ul>
        </div>

        <div class="footer-box">
            <h4>Bantuan</h4>
            <ul>
                <li><a href="#">Tentang Kami</a></li>
                <li><a href="#">Kebijakan Privasi</a></li>
                <li><a href="#">Kontak</a></li>
            </ul>
        </div>

        <div class="footer-newsletter">
            <h4>Status Situs</h4>
            <p>Data aktivitas pemain yang tercatat secara real-time di server kami.</p>
            <div class="f-stats">
                <div class="stat-item">
                    <span>Games</span>
                    <b><?php 
                        $total_games_count = $pdo->query("SELECT COUNT(*) FROM games")->fetchColumn();
                        echo number_format($total_games_count ? (int)$total_games_count : 0); 
                    ?></b>
                </div>
                <div class="stat-item">
                    <span>Plays</span>
                    <b><?php 
                        $total_plays_count = $pdo->query("SELECT SUM(views) FROM games")->fetchColumn();
                        echo number_format($total_plays_count ? (int)$total_plays_count : 0); 
                    ?></b>
                </div>
            </div>
        </div>
    </div>

    <div class="footer-bottom">
        <div class="f-copy">&copy; <?php echo date('Y'); ?> ArcadeFun. All Rights Reserved.</div>
        <div class="f-social">
            <a href="#" style="color: inherit; text-decoration: none; opacity: 0.3;">Admin Dashboard</a>
        </div>
    </div>
</footer>


<script>
    let offset = 21;
    let loading = false;
    let noMoreData = false;
    const grid = document.getElementById('game-grid');
    const loader = document.getElementById('loader');
    const sortType = '<?php echo $sort; ?>';

    function loadMore() {
        if (loading || noMoreData) return;
        loading = true;
        loader.style.display = 'block';

        fetch(`api_load_more.php?offset=${offset}&sort=${sortType}`)
            .then(res => res.json())
            .then(data => {
                if (data && data.length > 0) {
                    data.forEach(game => {
                        const card = `
                            <a href="game/${game.slug}" class="game-card">
                                <div class="card-inner">
                                    <img src="${game.image_url}" alt="${game.title}" loading="lazy">
                                    <div class="game-title">${game.title}</div>
                                </div>
                            </a>`;
                        grid.insertAdjacentHTML('beforeend', card);
                    });
                    offset += 21;
                    loading = false;
                } else {
                    noMoreData = true;
                }
                loader.style.display = 'none';
            })
            .catch(() => {
                loader.style.display = 'none';
                loading = false;
            });
    }

    // Scroll event dengan toleransi lebih besar untuk Firefox Mac
    window.addEventListener('scroll', () => {
        const scrollHeight = document.documentElement.scrollHeight;
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        const clientHeight = window.innerHeight;

        if (scrollTop + clientHeight >= scrollHeight - 1000) {
            loadMore();
        }
    }, { passive: true });
</script>
<?php echo get_ad_unit('gm-global'); ?>
</body>
</html>