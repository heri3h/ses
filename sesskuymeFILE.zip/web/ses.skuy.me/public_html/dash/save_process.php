<?php
require_once 'auth.php';
require_once '../config/db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = safe_input($_POST['title'] ?? '');
    $slug  = safe_input($_POST['slug'] ?? '');
    $url   = $_POST['url'] ?? ''; 
    $thumb_url = $_POST['thumb'] ?? '';
    $desc  = safe_input($_POST['desc'] ?? '');
    $cat   = safe_input($_POST['cat'] ?? '');

    // 1. Cek Duplikasi dengan PDO
    $stmt = $pdo->prepare("SELECT id FROM games WHERE slug = ?");
    $stmt->execute([$slug]);
    if ($stmt->fetch()) {
        echo json_encode(['status' => 'error', 'message' => 'Game sudah ada!']);
        exit;
    }

    // 2. Proses Kompres Gambar (Logika sama, hanya penyimpanan path)
    $target_dir = "../assets/thumbs/";
    if (!is_dir($target_dir)) mkdir($target_dir, 0755, true);
    $filename = $slug . ".jpg";
    $target_file = $target_dir . $filename;

    $final_thumb = $thumb_url;
    if (!empty($thumb_url)) {
        $img_data = @file_get_contents($thumb_url);
        if ($img_data !== false) {
            $src = @imagecreatefromstring($img_data);
            if ($src !== false) {
                imagejpeg($src, $target_file, 10);
                imagedestroy($src);
                $final_thumb = "assets/thumbs/" . $filename;
            }
        }
    }

    // 3. Insert dengan PDO
    $sql = "INSERT INTO games (title, slug, iframe_url, image_url, description, category) VALUES (?, ?, ?, ?, ?, ?)";
    try {
        $pdo->prepare($sql)->execute([$title, $slug, $url, $final_thumb, $desc, $cat]);
        echo json_encode(['status' => 'success']);
    } catch (PDOException $e) {
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
}